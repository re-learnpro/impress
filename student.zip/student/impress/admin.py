from django.contrib import admin
from .models import Impress

admin.site.register(Impress)

# Register your models here.
