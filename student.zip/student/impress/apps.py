from django.apps import AppConfig


class ImpressConfig(AppConfig):
    name = 'impress'
